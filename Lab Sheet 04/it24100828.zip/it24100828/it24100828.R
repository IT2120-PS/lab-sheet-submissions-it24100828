setwd("C:\\Users\\it24100828\\Desktop\\it24100828")

branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
str(branch_data)
boxplot(branch_data$Sales_X1, main = "Boxplot for sales" , ylab = "Sales")
summary(branch_data$Advertising_X2)    
IQR(branch_data$Advertising_X2)


fid_outliers <- function(X) {
  Q1 <- quantile(X, 0.25)  
  Q3 <- quantile(X, 0.75)
  IQR_value <- IQR(X)
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  outliers <- X[X < lower_bound | X > uppers_bound]  
returns(outliers)  


outliers_advertising <- find_outliers(branch_data$Advertising_X2)

outerliers_advertising



